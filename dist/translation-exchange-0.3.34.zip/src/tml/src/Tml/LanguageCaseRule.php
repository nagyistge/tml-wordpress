<?php

/**
 * Copyright (c) 2016 Translation Exchange, Inc
 *
 *  _______                  _       _   _             ______          _
 * |__   __|                | |     | | (_)           |  ____|        | |
 *    | |_ __ __ _ _ __  ___| | __ _| |_ _  ___  _ __ | |__  __  _____| |__   __ _ _ __   __ _  ___
 *    | | '__/ _` | '_ \/ __| |/ _` | __| |/ _ \| '_ \|  __| \ \/ / __| '_ \ / _` | '_ \ / _` |/ _ \
 *    | | | | (_| | | | \__ \ | (_| | |_| | (_) | | | | |____ >  < (__| | | | (_| | | | | (_| |  __/
 *    |_|_|  \__,_|_| |_|___/_|\__,_|\__|_|\___/|_| |_|______/_/\_\___|_| |_|\__,_|_| |_|\__, |\___|
 *                                                                                        __/ |
 *                                                                                       |___/
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

namespace Tml;

use Tml\RulesEngine\Evaluator;
use Tml\RulesEngine\Parser;

class LanguageCaseRule extends Base {

    /**
     * @var integer
     */
    public $id;
    /**
     * @var LanguageCase
     */
    public $language_case;

    /**
     * @var string
     */
    public $description;

    /**
     * @var string
     */
    public $examples;

    /**
     * @var string
     */
    public $conditions;

    /*
     * string[]
     */
    public $conditions_expression;

    /**
     * @var string
     */
    public $operations;

    /*
     * string[]
     */
    public $operations_expression;

    /**
     * @return array|int|string
     */
    function conditionsExpression() {
        if (!isset($this->conditions_expression)) {
            $p = new Parser($this->conditions);
            $this->conditions_expression = $p->parse();
        }
        return $this->conditions_expression;
    }

    /**
     * @return array|int|string
     */
    function operationsExpression() {
        if (!isset($this->operations_expression)) {
            $p = new Parser($this->operations);
            $this->operations_expression = $p->parse();
        }
        return $this->operations_expression;
    }

    /**
     * Some language cases may depend on the object gender.
     * This is the only context that is injected/hard coded into the language cases.
     *
     * The language must support Gender Context.
     *
     * @param $object
     * @return array
     */
    function genderVariables($object) {
        if (strstr($this->conditions, "@gender") == false)
            return array();

        if ($object == null)
            return array("@gender" => "unknown");

        $context = $this->language_case->language->contextByKeyword("gender");

        if ($context == null)
            return array("@gender" => "unknown");

        return $context->vars($object);
    }

    /**
     * @param mixed $value
     * @param null $object
     * @return bool|mixed
     */
    public function evaluate($value, $object = null) {
        if ($this->conditions == null)
            return false;

        $re = new Evaluator();
        $re->evaluate(array("let", "@value", $value));

        $vars = $this->genderVariables($object);
        foreach($vars as $key=>$val) {
            $re->evaluate(array("let", $key, $val));
        }

        return $re->evaluate($this->conditionsExpression());
    }

    /**
     * @param mixed $value
     * @return mixed
     */
    public function apply($value) {
        if ($this->operations == null)
            return $value;

        $re = new Evaluator();
        $re->evaluate(array("let", "@value", $value));

        return $re->evaluate($this->operationsExpression());
    }

}