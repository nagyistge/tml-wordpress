Tml Configuration
=================

This folder contains default configuration settings. Make sure you have the config.json file available.

You can create the file using the following command:

        $ cp defaults.json config.json


