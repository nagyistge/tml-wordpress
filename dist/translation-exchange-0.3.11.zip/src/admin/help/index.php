<div class="wrap" style="font-size:20px; padding:30px; text-align:center;">
    <img src="<?php echo plugins_url( 'translationexchange/assets/images/logo.png' ) ?>" style="width: 120px; margin: 20px;"><br>
<!--        <img src="--><?php //echo plugin_dir_url("assets/images/loading.png") ?><!--" style="vertical-align:bottom">-->
    Redirecting to documentation at <a href="http://welcome.translationexchange.com/docs/plugins/wordpress">http://welcome.translationexchange.com/docs/plugins/wordpress</a> ...
</div>

<script>
    window.setTimeout(function() {
        location.href = "http://welcome.translationexchange.com/docs/plugins/wordpress";
    }, 2000);
</script>

